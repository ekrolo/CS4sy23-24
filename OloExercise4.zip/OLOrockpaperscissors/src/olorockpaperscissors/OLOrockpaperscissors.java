/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package olorockpaperscissors;
import java.util.Scanner; 

/**
 *
 * @author elijahkhallel
 */
public class OLOrockpaperscissors {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Move rock = new Move("Rock");
	Move paper = new Move("Paper");
	Move scissors = new Move("Scissors");
		
	rock.setStrongAgainst(scissors);
	paper.setStrongAgainst(rock);
	scissors.setStrongAgainst(paper);
		
	int roundsToWin = 2;
        int userOption;
        int userScore = 0;
        int compScore = 0;
        boolean exit = false;
        
        Scanner scan = new Scanner(System.in);
        
        do {
            
            System.out.println("Welcome to Rock, Paper, Scissors. Please choose an option:");
            System.out.print("1. Start Game \n2. Change Number of Rounds \n3. Exit \n> ");
        
            userOption = scan.nextInt();
            
            if (userOption == 1) {
               System.out.printf("\n This match will be first to %d rounds. ", roundsToWin);
               
               for (int i = 0; i < roundsToWin; i++) {
                  int compMove = (int) Math.floor(Math.random()*3) + 1;
                  System.out.println("The computer has selected its move. Select your move: \n");
                  System.out.println("1. Rock \n2. Paper \n3. Scissors");
                  System.out.print("> ");
                  
                  int userMove = scan.nextInt();
                  
                  Move userMoveObject = null;
                  Move compMoveObject = null;
                  
                  switch (compMove) {
                      case 1: 
                          compMoveObject = rock;
                          break;
                          
                      case 2: 
                          compMoveObject = paper;
                          break;
                          
                      case 3: 
                          compMoveObject = scissors;
                          break;
                  }
                  
                  switch (userMove) {
                      case 1: 
                          userMoveObject = rock;
                          break;
                          
                      case 2: 
                          userMoveObject = paper;
                          break;
                          
                      case 3: 
                          userMoveObject = scissors;
                          break;
                  }
                  
                  int result = Move.compareMoves(userMoveObject, compMoveObject);
                  
                  if (result == 0) {
                   System.out.printf("Player chose: %s  Computer chose: %s", userMoveObject.getName(), compMoveObject.getName());
                   System.out.println("\nPlayer wins round! \n");
                   
                   userScore++;
               }
                  
                  else if (result == 1) {
                   System.out.printf("Player chose: %s  Computer chose: %s", userMoveObject.getName(), compMoveObject.getName());
                   System.out.println("\nComputer wins round! \n");
                      compScore++;
                  }
                  
                  else if (result == 2) {
                   System.out.printf("Player chose: %s  Computer chose: %s", userMoveObject.getName(), compMoveObject.getName());
                   System.out.println("\nIt was a draw! \n");
                  }
                  
                  System.out.printf("Player: %d - Computer: %d\n", userScore, compScore);
                 
               }
               
               if (userScore > compScore) {
                   System.out.println("\nPlayer Wins!\n");
               }
               else if (userScore < compScore) {
                   System.out.println("\nComputer Wins! (loser)\n");
               }
               else if (userScore == compScore) {
                   System.out.println("\nDraw Game!\n");
               }
            }
               
               else if (userOption == 2) {
                   System.out.println("Change number of rounds to: \n");
                   System.out.println("> ");
                   roundsToWin = scan.nextInt(); 
                   System.out.println("Successfully changed number of rounds! \n");
                   userScore = 0;
                   compScore = 0;
               }
               
               else if (userOption == 3) {
                   exit = true; 
                   System.out.println("Thank you for playing! ");
               }
               else {
                   System.out.println("Invalid option.");
               }
            
            
        } while (!exit);
        
        
        

        
       
        }
        
        
		
    }
    

